/*********************************************************************
*
*      Copyright (C) 2002 Andrew Khan
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
***************************************************************************/

package jxl.demo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import jxl.common.Logger;

import jxl.Cell;
import jxl.Range;
import jxl.Workbook;

/**
 * The main demo class which interprets the command line switches in order
 * to determine how to call the demo programs
 * The demo program uses stdout as its default output stream
 */
public class Demo
{
  private static final int CSVFormat = 13;
  private static final int XMLFormat = 14;

  /**
   * The logger
   */
  private static Logger logger = Logger.getLogger(Demo.class);

  /**
   * Displays the acceptable command line arguments
   */
  private static void displayHelp()
  {
      System.err.println
        ("Command format:  Demo [-unicode] [-csv] [-hide] excelfile");
      System.err.println("                 Demo -xml [-format]  excelfile");
      System.err.println("                 Demo -readwrite|-rw excelfile output");
      System.err.println("                 Demo -biffdump | -bd | -wa | -write | -formulas | -features | -escher | -escherdg excelfile");
      System.err.println("                 Demo -ps excelfile [property] [output]");
      System.err.println("                 Demo -version | -logtest | -h | -help");

  }

  /**
   * The main method.  Gets the worksheet and then uses the API 
   * within a simple loop to print out the spreadsheet contents as
   * comma separated values
   * 
   * @param args the command line arguments
   */


  /**
   * A private method to test the various find functions
   */
  private static void findTest(Workbook w)
  {
    logger.info("Find test");

    Cell c = w.findCellByName("named1");
    if (c != null)
    {
      logger.info("named1 contents:  " + c.getContents());
    }

    c = w.findCellByName("named2");
    if (c != null)
    {
      logger.info("named2 contents:  " + c.getContents());
    }

    c = w.findCellByName("namedrange");
    if (c != null)
    {
      logger.info("named2 contents:  " + c.getContents());
    }

    Range[] range = w.findByName("namedrange");
    if (range != null)
    {
      c = range[0].getTopLeft();
      logger.info("namedrange top left contents:  " + c.getContents());

      c = range[0].getBottomRight();
      logger.info("namedrange bottom right contents:  " + c.getContents());
    }

    range = w.findByName("nonadjacentrange");
    if (range != null)
    {
      for (int i = 0; i < range.length; i++)
      {
        c = range[i].getTopLeft();
        logger.info("nonadjacent top left contents:  " + c.getContents());
        
        c = range[i].getBottomRight();
        logger.info("nonadjacent bottom right contents:  " + c.getContents());
      }
    }

    range = w.findByName("horizontalnonadjacentrange");
    if (range != null)
    {
      for (int i = 0; i < range.length; i++)
      {
        c = range[i].getTopLeft();
        logger.info("horizontalnonadjacent top left contents:  " + 
                           c.getContents());
        
        c = range[i].getBottomRight();
        logger.info("horizontalnonadjacent bottom right contents:  " + 
                 c.getContents());
      }
    }

  }
}



