package fr.newcem.service.courseRunner;

import fr.newcem.model.DataSet;
import fr.newcem.model.IhmTestReport;
import fr.newcem.service.courseRunner.courses.SubsciptionCourse;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.File;

public class FirefoxRunner extends AbstractRunner{

    public IhmTestReport ExecuteCourse(DataSet dataSet){
        setUpReportDirectory(dataSet);


        File file = new File("C:\\Users\\moi\\Documents\\BOPCSNewCEMRobot\\seleniumDriver\\geckodriver.exe");
        System.setProperty("webdriver.gecko.driver", file.getAbsolutePath());
        DesiredCapabilities capabilities = DesiredCapabilities.firefox();
        capabilities.setCapability("marionette",true);
        driver = new FirefoxDriver();

        IhmTestReport ihmTestReport = new IhmTestReport(dataSet);

        SubsciptionCourse subsciptionCourse = new SubsciptionCourse(this, (RemoteWebDriver) driver, dataSet);

        driver.quit();
        reportFolderIndex ++;
        ihmTestReport.setFinishedDateAndExecutionTime();
        ihmTestReport.setNavigator("Firefox");
        return  ihmTestReport;
    }

}
