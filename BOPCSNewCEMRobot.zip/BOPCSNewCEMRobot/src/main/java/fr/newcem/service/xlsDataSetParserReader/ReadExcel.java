package fr.newcem.service.xlsDataSetParserReader;

import fr.newcem.model.DataSet;
import jxl.Cell;
import jxl.CellType;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


public class ReadExcel {



    private String inputFile;

    private ArrayList<String> xlsHeaderLabel;

    public ReadExcel(String inputFile) {
        this.inputFile = inputFile;
        try {
            read();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getInputFile() {
        return inputFile;
    }

    public void setInputFile(String inputFile) {
        this.inputFile = inputFile;
    }

    public void read() throws IOException  {
        File inputWorkbook = new File(inputFile);
        Workbook w;


        try {
            w = Workbook.getWorkbook(inputWorkbook);
            // Get the first sheet
            Sheet sheet = w.getSheet(0);
            // Loop over first 10 column and lines

            for (int j = 0; j < sheet.getColumns(); j++) {
                for (int i = 0; i < sheet.getRows(); i++) {
                    Cell cell = sheet.getCell(j, i);
                    CellType type = cell.getType();
                    if (type == CellType.LABEL) {
                        System.out.println("I got a label "
                                + cell.getContents());
                    }

                    if (type == CellType.NUMBER) {
                        System.out.println("I got a number "
                                + cell.getContents());
                    }

                }
            }
        } catch (BiffException e) {
            e.printStackTrace();
        }
    }

    public DataSet[] FindDataSets()  throws IOException  {
        DataSet[] dataSets= new DataSet[0];
        File inputWorkbook = new File(inputFile);
        Workbook w;

        try {
            w = Workbook.getWorkbook(inputWorkbook);
            Sheet sheet = w.getSheet(0);

            xlsHeaderLabel = new ArrayList<String>();
            for (int j = 0; j < sheet.getColumns(); j++) {
                xlsHeaderLabel.add(sheet.getCell(j, 0).getContents());
            }
            xlsHeaderLabel.add("Jouer");

            dataSets = new DataSet[sheet.getRows() -1 ];
            for (int i = 1; i < sheet.getRows(); i++) {
                DataSet dataSet = new DataSet();
                for (int j = 0; j < sheet.getColumns(); j++) {
                    Cell cell = sheet.getCell(j, i);
                    switch (j) {
                        case 0:
                            dataSet.setName(cell.getContents());
                            break;
                        case 1:
                            dataSet.setVin(cell.getContents());
                            break;
                        case 2:
                            dataSet.setNumeroContrat(cell.getContents());
                            break;

                        case 3:
                            dataSet.setNumeroClient(cell.getContents());
                            break;
                        case 4:
                            dataSet.setEvenementContrat(cell.getContents());
                            break;

                        case 5:
                            dataSet.setKmCompteur(cell.getContents());
                            break;
                    }
                    CellType type = cell.getType();
                    if (type == CellType.LABEL) {
                        System.out.println("I got a label "
                                + cell.getContents());
                    }

                    if (type == CellType.NUMBER) {
                        System.out.println("I got a number "
                                + cell.getContents());
                    }
                }
                if(i > 0)
                dataSets[i-1] = dataSet;

            }
        } catch (BiffException e) {
            e.printStackTrace();
        }
        return dataSets;

    }


    public ArrayList<String> getXlsHeaderLabel() {
        return xlsHeaderLabel;
    }
}