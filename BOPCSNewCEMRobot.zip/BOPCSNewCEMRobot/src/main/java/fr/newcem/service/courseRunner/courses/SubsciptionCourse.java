package fr.newcem.service.courseRunner.courses;

import fr.newcem.model.DataSet;
import fr.newcem.service.courseRunner.AbstractRunner;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.concurrent.TimeUnit;


/**
 * Created by moi on 30/12/2016.
 */
public class SubsciptionCourse {

    public SubsciptionCourse(AbstractRunner runner, RemoteWebDriver driver, DataSet dataSet ) {
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        driver.get("http://www.google.com");
        //driver.get("http://www.fnac.com");
        //driver.findElement(By.className("boxSelect")).sendKeys("css=img[alt=\"Google\"]");
        runner.captureScreen();

        //////driver.findElement(By.id("lst-ib")).sendKeys("css=img[alt=\"Google\"]");
        //////runner.captureScreen();

        //////driver.findElement(By.id("lst-ib")).submit();
        //WebElement element = driver.findElement(By.name("f"));
        //WebElement allFormChildElements = driver.findElement(By.xpath("//form[@name='q']/*"));    // Enter something to search for
        //allFormChildElements.sendKeys("Cheese!");
        // Now submit the form. WebDriver will find the form for us from the element
        //element.submit();

        // Check the title of the page
        //////System.out.println("Page title is: " + driver.getTitle());

        // Google's search is rendered dynamically with JavaScript.
        // Wait for the page to load, timeout after 10 seconds
        //(new WebDriverWait(driver, 10)).until(new ExpectedCondition<Boolean>() {
        //public Boolean apply(WebDriver d) {
        //return d.getTitle().toLowerCase().startsWith("cheese!");
        //}
        //});

        // Should see: "cheese! - Google Search"
        //////System.out.println("Page title is: " + driver.getTitle());

        //////runner.captureScreen();
    }
}
