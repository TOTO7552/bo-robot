package fr.newcem.service.xlsDataSetWriter;

import fr.newcem.model.IhmTestReport;
import fr.newcem.view.MainView;

import java.util.List;

public class XlsReportWriter {

    private MainView mainView;

    public XlsReportWriter(String xlsFilePath, MainView mainView) {
        this.mainView = mainView;
        List<IhmTestReport> ihmTestReportTableListModel = mainView.getExecutionPanel().getExecutionTableModel().getIhmTestReportTableListModel();
        WriteExcelReport writeExcelReport = new WriteExcelReport(xlsFilePath, ihmTestReportTableListModel);
    }
}
