package fr.newcem.service.xlsDataSetWriter;

import fr.newcem.model.DataSet;
import fr.newcem.model.Parameter;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class WriteExcelDataSets {

    public WriteExcelDataSets(String xlsFilePath, List<DataSet> dataSetdTableListModel) {
        WritableWorkbook workbook = null;
        try {
			/* On créé un nouveau worbook et on l'ouvre en écriture */
            workbook = Workbook.createWorkbook(new File(xlsFilePath));

			/* On créé une nouvelle feuille (test en position 0) et on l'ouvre en écriture */
            WritableSheet sheet = workbook.createSheet("Jeudx de données", 0);
            int rowIndex = 1;
            int colIndex = 0;

            for (DataSet dataSet : dataSetdTableListModel) {
                for (Parameter p: dataSet.getParameterList()) {
                    //label.setCellFormat(new C);
                    Label label = new Label(0, rowIndex, p.getName());
                    Label value = new Label(colIndex, rowIndex, p.getValue());
                    sheet.addCell(label);
                    sheet.addCell(value);
                    rowIndex++;

                }

                colIndex ++;

                Label label = new Label(4, 0, "Jeux de données");
                sheet.addCell(label);

                String formatedDate = "yyyy-MM-dd  H-mm";
                java.text.SimpleDateFormat formater = new java.text.SimpleDateFormat( formatedDate );
                java.util.Date date = new java.util.Date();
                formatedDate= formater.format( date ) ;
                Label generationDatelabel = new Label(5, 0, formatedDate);
                sheet.addCell(generationDatelabel);

                /* Creation d'un champ au format numerique */
                //NumberCell number = new Number(6, rowIndex, 3.1459);
                //sheet.addCell((Number) number);
            }

			/* On ecrit le classeur */
            workbook.write();

        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (RowsExceededException e) {
            e.printStackTrace();
        }
        catch (WriteException e) {
            e.printStackTrace();
        }
        finally {
            if(workbook!=null){
				/* On ferme le worbook pour libérer la mémoire */
                try {
                    workbook.close();
                }
                catch (WriteException e) {
                    e.printStackTrace();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }
}
