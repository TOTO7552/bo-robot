package fr.newcem.service.courseRunner;

import fr.newcem.model.DataSet;
import fr.newcem.model.IhmTestReport;
import fr.newcem.service.courseRunner.courses.SubsciptionCourse;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.File;

public class IERunner extends AbstractRunner{

    public IhmTestReport ExecuteCourse(DataSet dataSet){
        setUpReportDirectory(dataSet);

        File file = new File("C:\\Users\\moi\\Documents\\BOPCSNewCEMRobot\\seleniumDriver\\IEDriverServer.exe");
        System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
        driver = new InternetExplorerDriver() {};

        IhmTestReport ihmTestReport = new IhmTestReport(dataSet);

        SubsciptionCourse subsciptionCourse = new SubsciptionCourse(this, (RemoteWebDriver) driver, dataSet);

        driver.quit();
        reportFolderIndex ++;
        ihmTestReport.setFinishedDateAndExecutionTime();
        ihmTestReport.setNavigator("IE");
        return ihmTestReport;
    }
}
