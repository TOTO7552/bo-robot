package fr.newcem.service.courseRunner;

import fr.newcem.model.DataSet;
import fr.newcem.model.IhmTestReport;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;

public abstract class AbstractRunner {
    protected WebDriver driver;
    protected String reportFilePath;
    protected String screenShotsFilePath;
    protected int reportFolderIndex;
    protected int screenShotIndex;

    public AbstractRunner(){
        reportFolderIndex = 0;
        screenShotIndex = 0;
    }

    public void setReportFilePath(String reportFilePath){
        this.reportFilePath = reportFilePath;
    }


    public abstract  IhmTestReport ExecuteCourse(DataSet dataSet) ;


    protected void setUpReportDirectory(DataSet dataSet) {
        String dirName = reportFilePath + "\\";
        File destinationFile=new File(dirName+dataSet.getName() +"-" +reportFolderIndex);
        screenShotsFilePath = destinationFile+ "\\";
        dataSet.setScreenShotPath(screenShotsFilePath);
        dataSet.setScreenShotDirectory(destinationFile);
    }

    public void captureScreen() {

        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(scrFile, new File(screenShotsFilePath + "\\screenshot-"+screenShotIndex+".png"));
            screenShotIndex ++;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
