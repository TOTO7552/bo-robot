package fr.newcem.service.xlsDataSetWriter;

import fr.newcem.model.IhmTestReport;
import fr.newcem.view.MainView;

import java.util.List;

public class XlsDataSetsWriter {

    private MainView mainView;

    public XlsDataSetsWriter(String xlsFilePath, MainView mainView) {
        this.mainView = mainView;
        List<IhmTestReport> ihmTestReportTableListModel = mainView.getExecutionPanel().getExecutionTableModel().getIhmTestReportTableListModel();
        WriteExcelReport writeExcelReport = new WriteExcelReport(xlsFilePath, ihmTestReportTableListModel);
    }
}
