package fr.newcem.service.xlsDataSetParserReader;

import fr.newcem.model.DataSet;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by moi on 24/12/2016.
 */
public class XlsDataSetReader {

    DataSet[] dataSets;
    ReadExcel readExcel;
    public XlsDataSetReader() {

    }

    public String getInputFile() {
        return readExcel.getInputFile();
    }

    public DataSet[] getDataSets(String intputFilePath) {
        readExcel = new ReadExcel(intputFilePath);

        try {
            dataSets = readExcel.FindDataSets();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dataSets;
    }

    public ArrayList<String> getXlsHeaderlabels(){
        return readExcel.getXlsHeaderLabel();
    }
}
