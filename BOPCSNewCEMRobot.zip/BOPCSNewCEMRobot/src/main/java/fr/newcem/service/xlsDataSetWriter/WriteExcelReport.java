package fr.newcem.service.xlsDataSetWriter;

import fr.newcem.model.IhmTestReport;
import fr.newcem.model.Parameter;
import jxl.Workbook;
import jxl.format.Colour;
import jxl.format.Pattern;
import jxl.write.*;
import jxl.write.biff.RowsExceededException;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class WriteExcelReport {

    public WriteExcelReport(String xlsFilePath, List<IhmTestReport> ihmTestReportTableListModel) {
        WritableWorkbook workbook = null;
        try {
			/* On créé un nouveau worbook et on l'ouvre en écriture */
            workbook = Workbook.createWorkbook(new File(xlsFilePath));

			/* On créé une nouvelle feuille (test en position 0) et on l'ouvre en écriture */
            WritableSheet sheet = workbook.createSheet("Rapport", 0);
            int rowIndex = 1;
            int colIndex = 0;

            for (IhmTestReport ihmTesttReport : ihmTestReportTableListModel) {
                for (Parameter p: ihmTesttReport.getParameterList()) {
                    //LABELs
                    Label label = new Label(colIndex, rowIndex, p.getValue(), getCellFormat(Colour.GRAY_25, Pattern.GRAY_25));

                    //VALUES
                    Label value = null;
                    if(p.getName()== "Temps test") {
                        value = new Label(colIndex, rowIndex, p.getValue(), getCellFormat(Colour.WHITE, Pattern.PATTERN1));
                    }
                    else if(p.getName()== "Statut execution") {
                        if(p.getValue() == "ok")value = new Label(colIndex, rowIndex, p.getValue(), getCellFormat(Colour.LIGHT_GREEN, Pattern.PATTERN2));
                        if(p.getValue() == "anomalie détectée")value = new Label(colIndex, rowIndex, p.getValue(), getCellFormat(Colour.LIGHT_ORANGE, Pattern.PATTERN3));
                        if(p.getValue() == "interrompue")value = new Label(colIndex, rowIndex, p.getValue(), getCellFormat(Colour.DARK_RED, Pattern.PATTERN4));
                    }
                    else value = new Label(colIndex, rowIndex, p.getValue(), getCellFormat(Colour.WHITE, Pattern.PATTERN1));

                    sheet.addCell(label);
                    sheet.addCell(value);
                    rowIndex++;
                }

                colIndex ++;

                Label label = new Label(4, 0, "Rapport de test");
                sheet.addCell(label);

                String formatedDate = "yyyy-MM-dd  H-mm";
                java.text.SimpleDateFormat formater = new java.text.SimpleDateFormat( formatedDate );
                java.util.Date date = new java.util.Date();
                formatedDate= formater.format( date ) ;
                Label generationDatelabel = new Label(5, 0, formatedDate);
                sheet.addCell(generationDatelabel);

                /* Creation d'un champ au format numerique */
                //NumberCell number = new Number(6, rowIndex, 3.1459);
                //sheet.addCell((Number) number);
            }

			/* On ecrit le classeur */
            workbook.write();

        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (RowsExceededException e) {
            e.printStackTrace();
        }
        catch (WriteException e) {
            e.printStackTrace();
        }
        finally {
            if(workbook!=null){
				/* On ferme le worbook pour libérer la mémoire */
                try {
                    workbook.close();
                }
                catch (WriteException e) {
                    e.printStackTrace();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    private WritableCellFormat getCellFormat(Colour colour, Pattern pattern) {
        WritableFont cellFont = new WritableFont (WritableFont.TIMES,12);
        WritableCellFormat cellFormat = new WritableCellFormat(cellFont);
        try {
            cellFormat.setBackground(colour, pattern);
        } catch (WriteException e) {
            e.printStackTrace();
        }
        return cellFormat;
    }
}
