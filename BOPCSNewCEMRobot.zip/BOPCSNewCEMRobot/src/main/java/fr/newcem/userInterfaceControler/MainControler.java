package fr.newcem.userInterfaceControler;

import fr.newcem.model.DataSet;
import fr.newcem.service.courseRunner.FirefoxRunner;
import fr.newcem.service.courseRunner.IERunner;
import fr.newcem.service.xlsDataSetParserReader.XlsDataSetReader;
import fr.newcem.service.xlsDataSetWriter.XlsDataSetsWriter;
import fr.newcem.service.xlsDataSetWriter.XlsReportWriter;
import fr.newcem.view.MainView;

import javax.swing.*;
import java.io.File;

public class MainControler {

    private MainView mainView;
    private String xlsPath;
    private String reportsPath;
    private DataSet[] importedDataSets;
    private IERunner IERunner;
    private FirefoxRunner FirefoxRunner;

    public MainControler() {
        IERunner = new IERunner();
        FirefoxRunner = new FirefoxRunner();

    }

    public void SetXlsPath(String xlsPath){
        this.xlsPath = xlsPath;
    }

    public void SetReportPath(String reportsPath){
        this.reportsPath = reportsPath;
    }

    public void SetMainView(MainView mainView){
        this.mainView = mainView;
    }

    public void ImportXlsSource(){
        XlsDataSetReader xlsDataSetReader = new XlsDataSetReader();
        //importedDataSets = new DataSet[0];
        if(xlsPath == null)
        importedDataSets = xlsDataSetReader.getDataSets("C:\\Users\\moi\\Documents\\BOPCSNewCEMRobot\\jeu_de_données.xls");
        else importedDataSets = xlsDataSetReader.getDataSets(xlsPath);
        int i = mainView.getDataSetsPanel().getDataSetsTable().getRowCount();
        mainView.getDataSetsPanel().getDataSetTableModel().ClearTableModel();
        for (DataSet dataSet:importedDataSets) {
            mainView.getDataSetsPanel().getDataSetTableModel().addDataSet((dataSet));
        }

        mainView.getDataSetsPanel().getDataSetTableModel().setXlsHeaderLabel(xlsDataSetReader.getXlsHeaderlabels());

        mainView.getDataSetsPanel().getDataSetTableModel().fireTableStructureChanged();
        mainView.getDataSetsPanel().getDataSetTableModel().fireTableDataChanged();

    }

    public void ExportXlsReport(){
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        String formatedDate = "yyyy-MM-dd  H-mm";

        java.text.SimpleDateFormat formater = new java.text.SimpleDateFormat( formatedDate );
        java.util.Date date = new java.util.Date();

        formatedDate= formater.format( date ) ;

        int answer = chooser.showOpenDialog(mainView);
        if (answer == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            XlsReportWriter xlsReportWriter = new XlsReportWriter(file.getAbsolutePath() + "\\"+ "Rapport de test - " +formatedDate +".xls", mainView);

        }
    }

    public void ExportXlsDataSets(){
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        String formatedDate = "yyyy-MM-dd  H-mm";

        java.text.SimpleDateFormat formater = new java.text.SimpleDateFormat( formatedDate );
        java.util.Date date = new java.util.Date();

        formatedDate= formater.format( date ) ;

        int answer = chooser.showOpenDialog(mainView);
        if (answer == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            XlsDataSetsWriter xlsDataSetsWriter = new XlsDataSetsWriter(file.getAbsolutePath() + "\\"+ "Jeu de données - " +formatedDate +".xls", mainView);

        }
    }

    public void BeginUserCourse(){
        if(mainView.getSubscribeTemplatePanel().getIeCheckBox().getState()) {
            IERunner.setReportFilePath(reportsPath);
            mainView.getExecutionPanel().AddTestExecution(IERunner.ExecuteCourse(mainView.getDataSetsPanel().getDataSetTableModel().getSelectedDataSet()));
            mainView.getExecutionPanel().getExecutionTableModel().fireTableDataChanged();
        }
        if(mainView.getSubscribeTemplatePanel().getFirefoxCheckBox().getState()) {
            FirefoxRunner.setReportFilePath(reportsPath);
            mainView.getExecutionPanel().AddTestExecution(FirefoxRunner.ExecuteCourse(mainView.getDataSetsPanel().getDataSetTableModel().getSelectedDataSet()));
            mainView.getExecutionPanel().getExecutionTableModel().fireTableDataChanged();
        }
    }
    public void BeginAllCourses(){

        if(!mainView.getAlternNavCheckBOx().getState()) {
            if (mainView.getIeCheckBox().getState()) {
                IERunner.setReportFilePath(reportsPath);
                for (DataSet dataSet : mainView.getDataSetsPanel().getDataSetTableModel().getDataSetTableListModel()) {
                    if (dataSet.isTestPlayed()) {
                        mainView.getExecutionPanel().AddTestExecution(IERunner.ExecuteCourse(dataSet));
                        mainView.getExecutionPanel().getExecutionTableModel().fireTableDataChanged();
                    }
                }
            }
            if (mainView.getFirefoxCheckBox().getState()) {
                FirefoxRunner.setReportFilePath(reportsPath);
                for (DataSet dataSet : mainView.getDataSetsPanel().getDataSetTableModel().getDataSetTableListModel()) {
                    if (dataSet.isTestPlayed()) {
                        mainView.getExecutionPanel().AddTestExecution(FirefoxRunner.ExecuteCourse(dataSet));
                        mainView.getExecutionPanel().getExecutionTableModel().fireTableDataChanged();
                    }
                }
            }
        }else{
            IERunner.setReportFilePath(reportsPath);
            FirefoxRunner.setReportFilePath(reportsPath);
            for (DataSet dataSet : mainView.getDataSetsPanel().getDataSetTableModel().getDataSetTableListModel()) {
                if (dataSet.isTestPlayed()) {
                    if (mainView.getIeCheckBox().getState()) {
                        mainView.getExecutionPanel().AddTestExecution(IERunner.ExecuteCourse(dataSet));
                    }
                    if (mainView.getFirefoxCheckBox().getState()) {
                        mainView.getExecutionPanel().AddTestExecution(FirefoxRunner.ExecuteCourse(dataSet));
                    }

                    mainView.getExecutionPanel().getExecutionTableModel().fireTableDataChanged();
                }
            }
        }
    }
    public void BeginSelectedCourses(){

        if(!mainView.getAlternNavCheckBOx().getState()) {
            if (mainView.getIeCheckBox().getState()) {
                IERunner.setReportFilePath(reportsPath);
                for (int row : mainView.getDataSetsPanel().getJTable().getSelectedRows()) {
                    mainView.getExecutionPanel().AddTestExecution(IERunner.ExecuteCourse(mainView.getDataSetsPanel().getDataSetTableModel().getDataSetTableListModel().get(row)));
                    mainView.getExecutionPanel().getExecutionTableModel().fireTableDataChanged();
                }
            }
            if (mainView.getFirefoxCheckBox().getState()) {
                FirefoxRunner.setReportFilePath(reportsPath);
                for (int row : mainView.getDataSetsPanel().getJTable().getSelectedRows()) {
                    mainView.getExecutionPanel().AddTestExecution(FirefoxRunner.ExecuteCourse(mainView.getDataSetsPanel().getDataSetTableModel().getDataSetTableListModel().get(row)));
                    mainView.getExecutionPanel().getExecutionTableModel().fireTableDataChanged();
                }
            }
        }else{
            FirefoxRunner.setReportFilePath(reportsPath);
            for (int row : mainView.getDataSetsPanel().getJTable().getSelectedRows()) {
                IERunner.setReportFilePath(reportsPath);
                mainView.getExecutionPanel().AddTestExecution(IERunner.ExecuteCourse(mainView.getDataSetsPanel().getDataSetTableModel().getDataSetTableListModel().get(row)));
                mainView.getExecutionPanel().getExecutionTableModel().fireTableDataChanged();
                FirefoxRunner.setReportFilePath(reportsPath);
                mainView.getExecutionPanel().AddTestExecution(FirefoxRunner.ExecuteCourse(mainView.getDataSetsPanel().getDataSetTableModel().getDataSetTableListModel().get(row)));
                mainView.getExecutionPanel().getExecutionTableModel().fireTableDataChanged();
            }
        }
    }
    public void DeleteSelectedDataset(){
        int[] selectedRows = mainView.getDataSetsPanel().getDataSetTableModel().getJTable().getSelectedRows();

        for (int i= selectedRows.length-1; i>=0;i--) {
            mainView.getDataSetsPanel().getDataSetTableModel().getDataSetTableListModel().remove(selectedRows[i]);
        }
        mainView.getDataSetsPanel().getDataSetTableModel().fireTableDataChanged();
    }



    public void ignoreSelectedTest(){
        for (int i: mainView.getDataSetsPanel().getJTable().getSelectedRows()) {
            DataSet dataSet = mainView.getDataSetsPanel().getDataSetTableModel().getDataSetTableListModel().get(i);
            if(dataSet.isTestPlayed() == false) {
                dataSet.setIgnoredTest(true);
                mainView.getSubscribeTemplatePanel().setGlobalGridPanelColor(new java.awt.Color(100, 150, 200));
            }else {
                mainView.getSubscribeTemplatePanel().setGlobalGridPanelColor(new java.awt.Color(200, 150, 120));
                dataSet.setIgnoredTest(false);
            }
        }

        mainView.getDataSetsPanel().getJTable().repaint();
    }

    public DataSet[] getImportedDataSets() {
        return importedDataSets;
    }

    public void repaintMainView(){
        mainView.repaint();
    }

    public void DeleteSelectedReport(){

        int[] selectedRows = mainView.getExecutionPanel().getExecutionTable().getSelectedRows();

        for (int i= selectedRows.length-1; i>=0;i--) {
            mainView.getExecutionPanel().getExecutionTableModel().getIhmTestReportTableListModel().remove(selectedRows[i]);
        }
        mainView.getExecutionPanel().getExecutionTableModel().fireTableDataChanged();

    }

    public MainView getMainView() {
        return this.mainView;
    }
}
