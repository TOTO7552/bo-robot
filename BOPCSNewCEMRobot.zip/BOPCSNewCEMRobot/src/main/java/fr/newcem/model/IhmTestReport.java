package fr.newcem.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * Created by moi on 18/12/2016.
 */
public class IhmTestReport extends DataSet {
    private String navigator;
    private String startedExecutionDate;
    private String finishedExecutionDate;
    private long executionTime;
    private String executionStatut;
    private ArrayList<String> executionDetails;
    private String testorComment;

    private Date startedExecutionDateDate;


    public IhmTestReport(DataSet parentActionDataSet){

        //Benefiçions de la mise à jour définie dans DataSet dont on hérite
        UpdateActionTemplate(parentActionDataSet);

        //Ajouts d'attributs
        String formatedDate = "yyyy-MM-dd  H-mm-ss";
        java.text.SimpleDateFormat formater = new java.text.SimpleDateFormat( formatedDate );
        startedExecutionDateDate= new java.util.Date();
        formatedDate= formater.format( startedExecutionDateDate ) ;
        this.startedExecutionDate = formatedDate;
        this.executionStatut = "ok";
        this.executionDetails = new ArrayList<String>();
        this.testorComment = "";
    }

    public String getStartedExecutionDate(){return this.startedExecutionDate;    }

    public String getExecutionStatut(){
        return this.executionStatut;
    }
    public void setExecutionStatut(String executionStatut) {this.executionStatut = executionStatut;}

    public ArrayList<Parameter> getParameterList(){
        ArrayList<Parameter> parameterList = new ArrayList<Parameter>();
        parameterList.add(new Parameter("id. de test",              getName()));
        parameterList.add(new Parameter("Statut execution",         getExecutionStatut()));
        parameterList.add(new Parameter("Début test",               getStartedExecutionDate()));
        parameterList.add(new Parameter("Fin test",                 getFinishedExecutionDate()));
        parameterList.add(new Parameter("Temps test",               getExecutionTime()));
        parameterList.add(new Parameter("Evènement",                getEvenementContrat()));
        parameterList.add(new Parameter("Km au compteur",           getKmCompteur()));
        parameterList.add(new Parameter("N° Contrat",               getNumeroContrat()));
        parameterList.add(new Parameter("VIN",                      getVin()));
        parameterList.add(new Parameter("N° Client",                getNumeroClient()));
        parameterList.add(new Parameter("DPI MADAX",                getDpiMadax()));
        parameterList.add(new Parameter("DDC",                      getDdc()));
        parameterList.add(new Parameter("Marque",                   getFilMarque()));
        parameterList.add(new Parameter("PDV",                      getFilPdv()));
        parameterList.add(new Parameter("Détail execution",         getExecutionDetailsString()));
        parameterList.add(new Parameter("Commentaire testeur",      getTestorComment()));

        return parameterList;
    }

    public String getNavigator() {
        return navigator;
    }

    public void setNavigator(String navigator) {
        this.navigator = navigator;
    }
    public void setFinishedDateAndExecutionTime() {
        String formatedDate = "yyyy-MM-dd  H-mm-ss";
        java.text.SimpleDateFormat formater = new java.text.SimpleDateFormat( formatedDate );
        java.util.Date date = new java.util.Date();
        formatedDate= formater.format( date ) ;
        finishedExecutionDate = formatedDate;

        executionTime = getDateDiff(startedExecutionDateDate , date, TimeUnit.MILLISECONDS);
    }

    public String getFinishedExecutionDate() {
        return finishedExecutionDate;
    }

    public long getExecutionTime() {
        return executionTime;
    }
    public static long getDateDiff(Date date1, Date date2, TimeUnit timeUnit) {
        long diffInMillies = date2.getTime() - date1.getTime();
        return timeUnit.convert(diffInMillies,TimeUnit.MILLISECONDS);
    }

    public ArrayList<String> getExecutionDetailsList() {
        return executionDetails;
    }
    public void addExecutionDetails(String executionDetail) {
        this.executionDetails.add(executionDetail);
    }

    public String getExecutionDetailsString(){
        String details = new String();
        for (String execDetails:getExecutionDetailsList()) {
            details += execDetails;
            details += "\n";
        }
        return  details;
    }

    public String getTestorComment() {
        return testorComment;
    }

    public void setTestorComment(String testorComment) {
        this.testorComment = testorComment;
    }
}
