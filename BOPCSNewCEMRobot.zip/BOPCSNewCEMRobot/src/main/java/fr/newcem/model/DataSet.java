package fr.newcem.model;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by moi on 18/12/2016.
 */
public class DataSet {



    private String screenShotDirectoryPath;
    private File screenShotDirectory;


    private boolean played;

    private String name;
    private String filMarque;
    private String filPdv;
    private String vin;
    private String evenementContrat;
    private String dpiMadax;
    private String ddc;
    private String numeroClient;

    private String numeroContrat;

    private String kmCompteur;

    public DataSet(){
        played = true;
    }

    public void UpdateActionTemplate(DataSet dataSet){
        this.name = dataSet.getName();
        this.filMarque = dataSet.getFilMarque();
        this.filPdv = dataSet.getFilPdv();
        this.vin = dataSet.getVin();
        this.evenementContrat = dataSet.getEvenementContrat();
        this.dpiMadax = dataSet.getDpiMadax();
        this.ddc = dataSet.getDdc();
        this.numeroClient = dataSet.getNumeroClient();

        this.screenShotDirectoryPath = dataSet.getScreenShotDirectoryPath();
        this.screenShotDirectory = dataSet.getScreenShotDirectory();

    }
    public String getScreenShotDirectoryPath() {
        return screenShotDirectoryPath;
    }
    public void setScreenShotPath(String screenShotDirectoryPath){
        this.screenShotDirectoryPath = screenShotDirectoryPath;
    }

    public File getScreenShotDirectory() {
        return screenShotDirectory;
    }

    public void setScreenShotDirectory(File screenShotDirectory){
        this.screenShotDirectory = screenShotDirectory;
    }

    public void setIgnoredTest(boolean ignored ){
        this.played = ignored;
    }
    public boolean isTestPlayed() {
        return this.played;
    }
    public String getName() {
            return name;
    }

    public void setName(String name) {
            this.name = name;
    }

    public String getFilMarque() {
            return filMarque;
    }

    public void setFilMarque(String filMarque) {
            this.filMarque = filMarque;
    }

    public String getFilPdv() {
            return filPdv;
    }

    public void setFilPdv(String filPdv) {
            this.filPdv = filPdv;
    }

    public String getVin() {
            return vin;
    }

    public void setVin(String vin) {
            this.vin = vin;
    }

    public String getEvenementContrat() {
            return evenementContrat;
    }

    public void setEvenementContrat(String evenementContrat) {
            this.evenementContrat = evenementContrat;
    }

    public String getDpiMadax() {
            return dpiMadax;
    }

    public void setDpiMadax(String dpiMadax) {
            this.dpiMadax = dpiMadax;
    }

    public String getDdc() {
            return ddc;
    }

    public void setDdc(String ddc) {
            this.ddc = ddc;
    }

    public String getNumeroClient() {
            return numeroClient;
    }

    public void setNumeroClient(String numeroClient) {
                this.numeroClient = numeroClient;
        }

    public String getKmCompteur() {
        return kmCompteur;
    }

    public void setKmCompteur(String kmCompteur) {
        this.kmCompteur = kmCompteur;
    }

    public String getNumeroContrat() {
        return numeroContrat;
    }

    public void setNumeroContrat(String numeroContrat) {
        this.numeroContrat = numeroContrat;
    }

    public ArrayList<Parameter> getParameterList(){
        ArrayList<Parameter> parameterList = new ArrayList<Parameter>();
        parameterList.add(new Parameter("id. de test",              getName()));
        parameterList.add(new Parameter("Evènement",                getEvenementContrat()));
        parameterList.add(new Parameter("Km au compteur",           getKmCompteur()));
        parameterList.add(new Parameter("N° Contrat",               getNumeroContrat()));
        parameterList.add(new Parameter("VIN",                      getVin()));
        parameterList.add(new Parameter("N° Client",                getNumeroClient()));
        parameterList.add(new Parameter("DPI MADAX",                getDpiMadax()));
        parameterList.add(new Parameter("DDC",                      getDdc()));
        parameterList.add(new Parameter("Marque",                   getFilMarque()));
        parameterList.add(new Parameter("PDV",                      getFilPdv()));

        return parameterList;
    }

}
