package fr.newcem.view;

import fr.newcem.userInterfaceControler.MainControler;
import fr.newcem.view.panel.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;


public class MainView extends JFrame {

    private MainControler mainControler;

    private DataSetsPanel dataSetsPanel;
    private SubscribeTemplatePanel subscribeTemplatePanel;
    private ExecutionPanel executionPanel;
    private ExecDetailsPanel execDetailsPanel;

    private JLabel templatesListTitle;
    private ScreenShotsPanel screenShotsPanel;

    private Checkbox ieCheckBox;
    private Checkbox firefoxCheckBox;
    private Checkbox alternNavCheckBOx;

    public MainView(MainControler mainControler) throws HeadlessException {
        this.mainControler = mainControler;
        this.setLayout(new BorderLayout(5,5));

        JPanel listPanelWrapper= new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        listPanelWrapper.setBackground(Color.GRAY);

        gbc.fill = GridBagConstraints.HORIZONTAL;

        //templatesListTitle.setForeground(Color.white);
        JPanel buttonsPanel = new JPanel(new GridBagLayout());
        Dimension buttonsDim = new Dimension(40,15);
        //buttonsPanel.setPreferredSize(new Dimension(200, 200));
        buttonsPanel.setBorder(BorderFactory.createLineBorder(Color.black));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(5,10,0,5);
        buttonsPanel.add(createDeleteButton(),gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        buttonsPanel.add(createIgnoreButton(),gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        buttonsPanel.add(createPlaySelectionButton(),gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        buttonsPanel.add(createPlayAllButton(),gbc);
        ieCheckBox =new Checkbox("IE",true);
        firefoxCheckBox = new Checkbox("Firefox",false);
        alternNavCheckBOx = new Checkbox("Alterner nav. à chaque test",false);
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        buttonsPanel.add(ieCheckBox,gbc);
        gbc.gridx = 1;
        gbc.gridy = 4;
        buttonsPanel.add(firefoxCheckBox,gbc);
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        buttonsPanel.add(alternNavCheckBOx,gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        listPanelWrapper.add(buttonsPanel, gbc);

        JPanel importButtonsWrapperPanel = new JPanel(new GridBagLayout());
        importButtonsWrapperPanel.setBackground(Color.GRAY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        this.templatesListTitle = new JLabel("Jeux de données:");
        listPanelWrapper.add(templatesListTitle, gbc);
        gbc.gridx = 1;
        importButtonsWrapperPanel.add(createDefineXlsPathButton(),gbc);
        gbc.gridx = 2;
        importButtonsWrapperPanel.add(createSelectExcelToImportButton(),gbc);
        gbc.gridx = 3;
        importButtonsWrapperPanel.add(createSaveScenarioChooser(),gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        listPanelWrapper.add(importButtonsWrapperPanel, gbc);

        //DATASETS PANEL
        subscribeTemplatePanel = new SubscribeTemplatePanel(mainControler);
        subscribeTemplatePanel.setBorder(BorderFactory.createLineBorder(Color.black));
        dataSetsPanel = new DataSetsPanel(mainControler, subscribeTemplatePanel);
        gbc.gridx = 1;
        gbc.gridy = 1;
        listPanelWrapper.add(dataSetsPanel, gbc);
        gbc.gridx = 2;
        gbc.gridy = 0;
        listPanelWrapper.add(new JLabel("Jeu: "), gbc);
        gbc.gridx = 2;
        gbc.gridy = 1;
        listPanelWrapper.add(subscribeTemplatePanel, gbc);


        //TESTING QUEUE PANEL
        SubscribeTemplatePanel subscribeTemplatePanel2 = new SubscribeTemplatePanel(mainControler);
        executionPanel = new ExecutionPanel(mainControler, subscribeTemplatePanel2);
        JPanel buttonsPanel2 = new JPanel(new GridBagLayout());
        buttonsPanel2.setBackground(Color.GRAY);

        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel executionGroupTitle = new JLabel("Rapports d'execution:");
        //executionGroupTitle.setForeground(Color.white);
        listPanelWrapper.add(executionGroupTitle,gbc);
        //buttonsPanel2.setPreferredSize(new Dimension(150, 180));
        //buttonsPane2.setBorder(BorderFactory.createLineBorder(Color.black));
        gbc.gridx = 0;
        gbc.gridy = 0;
        buttonsPanel2.add(createDeleteReportButton(),gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        buttonsPanel2.add(createDefineXlsExportPathButton(),gbc);
        gbc.gridx = 2;
        gbc.gridy = 0;
        buttonsPanel2.add(createExportXslRepportButton(),gbc);
        JPanel buttonPanel2container = new JPanel();
        buttonPanel2container.setBackground(Color.GRAY);
        //buttonPanel2container.setPreferredSize(new Dimension(200, 40));
        buttonPanel2container.add(buttonsPanel2);
        //buttonPanel2container.setBorder(BorderFactory.createLineBorder(Color.black));


        subscribeTemplatePanel.SetSubscribeTemplatePanel(dataSetsPanel, executionPanel);


        gbc.gridx = 2;
        gbc.gridy = 2;
        listPanelWrapper.add( new JLabel("Détails rapport:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        listPanelWrapper.add(buttonPanel2container, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        listPanelWrapper.add(executionPanel, gbc);
        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        execDetailsPanel = new ExecDetailsPanel(mainControler,executionPanel.getExecutionTable(), executionPanel.getExecutionTableModel());
        listPanelWrapper.add(execDetailsPanel,gbc);
        executionPanel.setExecDetailsPanel(execDetailsPanel);

        screenShotsPanel = new ScreenShotsPanel(mainControler, executionPanel.getExecutionTable(), executionPanel.getExecutionTableModel());
        //screenShotsPanel.setPreferredSize(new Dimension(500, 100));


        //listPanelWrapper.add(screenShotsPanel);
        executionPanel.setScreenShotPanel(screenShotsPanel);

        //this.add(subscribeTemplatePanel,BorderLayout.WEST);

        JScrollPane scrollPane1 = new JScrollPane(listPanelWrapper);
        scrollPane1.createHorizontalScrollBar();
        scrollPane1.setPreferredSize(new Dimension(200, 185));
        this.add(scrollPane1,BorderLayout.CENTER);

        JScrollPane scrollPane = new JScrollPane(screenShotsPanel);
        scrollPane.createHorizontalScrollBar();
        scrollPane.setPreferredSize(new Dimension(200, 185));
        this.add(scrollPane,BorderLayout.SOUTH);
        //this.setBackground(Color.PINK);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1170, 735);
        this.setTitle("Tests auto");
        this.setVisible(true);
    }

    private JButton createDefineXlsPathButton() {
        return new JButton(new AbstractAction("Definir .xls") {
            public void actionPerformed(ActionEvent actionEvent) {
                JFileChooser chooser = new JFileChooser();
                chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

                int answer = chooser.showOpenDialog(MainView.this);
                if (answer == JFileChooser.APPROVE_OPTION) {
                    File file = chooser.getSelectedFile();
                    mainControler.SetXlsPath(file.getAbsolutePath());
                }
            }
        });
    }

    private JButton createSelectExcelToImportButton() {
        return new JButton(new AbstractAction("Importer les données") {
            public void actionPerformed(ActionEvent actionEvent) {
               mainControler.ImportXlsSource() ;

            }
        });
    }

    private JButton createIgnoreButton() {
        return new JButton(new AbstractAction("Ignorer jeu") {
            public void actionPerformed(ActionEvent actionEvent) {
                mainControler.ignoreSelectedTest();
            }
        });
    }

    private JButton createDeleteButton() {
        return new JButton(new AbstractAction("Retirer jeu") {
            public void actionPerformed(ActionEvent actionEvent) {

                mainControler.DeleteSelectedDataset();
            }
        });
    }

    private JButton createSaveScenarioChooser() {
        return new JButton(new AbstractAction("Exporter le scénario") {
            public void actionPerformed(ActionEvent actionEvent) {
                mainControler.ExportXlsDataSets();
            }
        });
    }

    private JButton createPlayAllButton() {
        return new JButton(new AbstractAction("Tout jouer") {
            public void actionPerformed(ActionEvent e) {
                mainControler.BeginAllCourses();
            }
        });
    }

    private JButton createPlaySelectionButton() {
        return new JButton(new AbstractAction("Jouer sélection") {
            public void actionPerformed(ActionEvent e) {
                mainControler.BeginSelectedCourses();
            }
        });
    }
    private JButton createDefineXlsExportPathButton() {
        return new JButton(new AbstractAction("Placer screenshots") {
            public void actionPerformed(ActionEvent actionEvent) {
                JFileChooser chooser = new JFileChooser();
                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

                int answer = chooser.showOpenDialog(MainView.this);
                if (answer == JFileChooser.APPROVE_OPTION) {
                    File file = chooser.getSelectedFile();
                    mainControler.SetReportPath(file.getAbsolutePath());
                }
            }
        });
    }


    private JButton createDeleteReportButton() {
        return new JButton(new AbstractAction("Retirer execution") {
            public void actionPerformed(ActionEvent actionEvent) {

                mainControler.DeleteSelectedReport();
            }
        });
    }

    private JButton createExportXslRepportButton() {
        return new JButton(new AbstractAction("Générer rapport") {
            public void actionPerformed(ActionEvent e) {

                mainControler.ExportXlsReport();
            }
        });
    }

    public DataSetsPanel getDataSetsPanel() {
        return dataSetsPanel;
    }
    public SubscribeTemplatePanel getSubscribeTemplatePanel() {
        return subscribeTemplatePanel;
    }
    public ExecutionPanel getExecutionPanel() {
        return executionPanel;
    }

    public JTable getDataSetsJTable(){
        return dataSetsPanel.getJTable();
    }

    public Checkbox getIeCheckBox() {
        return ieCheckBox;
    }

    public Checkbox getFirefoxCheckBox() {
        return firefoxCheckBox;
    }

    public Checkbox getAlternNavCheckBOx() {
        return alternNavCheckBOx;
    }
}
