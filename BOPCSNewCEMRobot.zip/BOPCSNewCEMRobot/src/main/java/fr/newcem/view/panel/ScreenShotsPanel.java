package fr.newcem.view.panel;

import fr.newcem.userInterfaceControler.MainControler;
import fr.newcem.model.IhmTestReport;
import fr.newcem.view.tableModel.ExecutionTableModel;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;

public class ScreenShotsPanel extends JPanel {
    private MainControler mainControler;
    private JTable executionJTable;
    private ExecutionTableModel executionTableModel;
    private IhmTestReport ihmTestReport;
    private String selectedIhmTestReportScreenShotPath;
    private File selectedIhmTestReportScreenShotDirectory;
    private ArrayList<ImageIcon> imageIcons;

    public ScreenShotsPanel(MainControler mainControler, JTable executionJTable, ExecutionTableModel executionTableModel) {
        this.mainControler = mainControler;
        this.executionJTable = executionJTable;
        this.executionTableModel = executionTableModel;
        imageIcons = new ArrayList<ImageIcon>();
        this.init();
    }

    public void init() {

        //this.setPreferredSize(new Dimension(800, 76));
        setBackground(Color.GRAY);

        //JScrollPane scrollPane = new JScrollPane(this);
        //scrollPane.createHorizontalScrollBar();
        //this.add(scrollPane, BorderLayout.CENTER);
        //JScrollPane scrollPane = new JScrollPane(this);
        //scrollPane.createHorizontalScrollBar();
        //scrollPane.setPreferredSize(new Dimension(800, 76));

    }

    public void updateDisplayedScreenShots(){
        if(executionJTable.getSelectedRow() < executionTableModel.getIhmTestReportTableListModel().size() && executionJTable.getSelectedRow() >=0)
            ihmTestReport = executionTableModel.getIhmTestReportTableListModel().get(executionJTable.getSelectedRow());
        else{
            this.removeAll();
            this.revalidate();
            this.repaint();
            return;
        }
        System.out.print(ihmTestReport.getScreenShotDirectory().getAbsolutePath());

        selectedIhmTestReportScreenShotDirectory = ihmTestReport.getScreenShotDirectory();

        imageIcons = new ArrayList<ImageIcon>();

        File[] filesInDirectory = selectedIhmTestReportScreenShotDirectory.listFiles();
        if(filesInDirectory != null) {
            for (File fileName : filesInDirectory) {
                imageIcons.add(new ImageIcon(fileName.getPath()));
            }
            this.removeAll();
            for (ImageIcon imgIcon : imageIcons) {
                Image img = imgIcon.getImage();
                Image resizedImage =
                        img.getScaledInstance(204, 152, java.awt.Image.SCALE_SMOOTH);
                imgIcon = new ImageIcon(resizedImage);
                JLabel label = new JLabel();
                label.setIcon(imgIcon);
                label.setPreferredSize(new Dimension(204, 152));
                this.add(label);
                this.revalidate();
            }
        }

    }
}
