package fr.newcem.view.panel;

import fr.newcem.model.DataSet;
import fr.newcem.model.IhmTestReport;
import fr.newcem.userInterfaceControler.MainControler;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class SubscribeTemplatePanel extends JPanel {
    private MainControler mainControler;

    private JLabel panelTitle;

    private JLabel labelTemplateName;
    private JTextField testIdentifiantTextField;
    private JTextField vinTextField;
    private JTextField numContratTextField;
    private JTextField numCLientTextField;
    private JTextField EvenementTextField;
    private JTextField kmCompteurTextField;
    private JTextField testDpiMadax;
    private JTextField testDdc;
    private JTextField testOffre;

    private Checkbox ieCheckBox;
    private Checkbox firefoxCheckBox;

    private JPanel globalGridPanel;

    public SubscribeTemplatePanel( MainControler mainControler) {
        this.mainControler = mainControler;
        this.init();
    }

    private DataSetsPanel dataSetsPanel;

    private ExecutionPanel executionPanel;

    public void init() {

        //String actionCode []= {"SO","AN","AV","RS","MS","TR"};
        this.setLayout(new BorderLayout());
        setPreferredSize(new Dimension(300, 200));
        //NORTH: TITLE
        //this.panelTitle = new JLabel("Jeu:");

        //WEST: PANELS

        JPanel labelsPanelWrapper = new JPanel();

        JPanel labelsPanel = new JPanel(new GridLayout(0,  2,  5,  5));
        labelsPanel.setPreferredSize(new Dimension(250,200));

        labelsPanel.add(new JLabel("Identifiant de test:"));
        testIdentifiantTextField = new JTextField("");
        labelsPanel.add(testIdentifiantTextField);

        labelsPanel.add(new JLabel("VIN:"));
        vinTextField = new JTextField("");
        labelsPanel.add(vinTextField);

        labelsPanel.add(new JLabel("N° contrat PCS:"));
        numContratTextField = new JTextField("");
        labelsPanel.add(numContratTextField);

        labelsPanel.add(new JLabel("N°client:"));
        numCLientTextField = new JTextField("");
        labelsPanel.add(numCLientTextField);

        labelsPanel.add(new JLabel("Evenement:"));
        EvenementTextField = new JTextField("");
        labelsPanel.add(EvenementTextField);

        labelsPanel.add(new JLabel("Km au compteur:"));
        kmCompteurTextField = new JTextField("");
        labelsPanel.add(kmCompteurTextField);

        labelsPanel.add(new JLabel("DPI Madax:"));
        testDpiMadax = new JTextField("");
        labelsPanel.add(testDpiMadax);

        labelsPanel.add(new JLabel("DDC:"));
        testDdc = new JTextField("");
        labelsPanel.add(testDdc);

        labelsPanel.add(new JLabel("Services contrat(s): "));
        testOffre = new JTextField("1-36-30000");
        labelsPanel.add(testOffre);

        labelsPanelWrapper.add(labelsPanel);

        JScrollPane labelsScrollPane = new JScrollPane(labelsPanelWrapper);
        labelsScrollPane.setPreferredSize(new Dimension(270, 150));

        //South: BUTTONS
        JPanel buttonsPanel = new JPanel(new GridBagLayout());
        buttonsPanel.setPreferredSize(new Dimension(320, 40));
        //buttonsPanel.setBorder(BorderFactory.createLineBorder(Color.black));
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0,5,0,0);
        buttonsPanel.add(createStartButton(), gbc);
        gbc.gridx = 1;
        buttonsPanel.add(createBackgroundChooser(), gbc);
        gbc.gridx = 2;
        buttonsPanel.add(createExecutionButton(), gbc);

        JPanel westPanel = new JPanel(new GridBagLayout());
        gbc.fill = GridBagConstraints.VERTICAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        westPanel.add(labelsScrollPane, gbc);

        ieCheckBox = new Checkbox("IE",true);
        firefoxCheckBox = new Checkbox("Firefox",false);
        gbc.gridx = 1;
        gbc.gridy = 1;
        buttonsPanel.add(ieCheckBox, gbc);
        gbc.gridx = 2;
        gbc.gridy = 1;
        buttonsPanel.add(firefoxCheckBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        westPanel.add(buttonsPanel, gbc);

        //JScrollPane scrollPane = new JScrollPane(westPanel);
        //scrollPane.createHorizontalScrollBar();
        //scrollPane.setPreferredSize(new Dimension(300, 150));

        globalGridPanel = new JPanel();
        //globalGridPanel.setBorder(BorderFactory.createLineBorder(Color.black));
        gbc.gridx = 0;
        gbc.gridy = 0;
        globalGridPanel.add(westPanel,gbc);
        //this.add(panelTitle,BorderLayout.NORTH);
        this.add(globalGridPanel,BorderLayout.CENTER);
        //this.add(buttonsPanel,BorderLayout.SOUTH);
        //this.add(textFieldPanelWrapper,BorderLayout.CENTER);

    }

    private JButton createExecutionButton() {
        return new JButton(new AbstractAction("Jouer") {
            public void actionPerformed(ActionEvent actionEvent) {
                mainControler.BeginUserCourse();
            }
        });
    }

    private JButton createStartButton() {
        return new JButton(new AbstractAction("Dupliquer") {
            public void actionPerformed(ActionEvent e) {
                dataSetsPanel.addDataSet(extractActionTemplateFromFormSubscribeTemplatePanel());
            }
        });
    }

    private JButton createBackgroundChooser() {
        return new JButton(new AbstractAction("Mètre à jour") {
            public void actionPerformed(ActionEvent actionEvent) {
                dataSetsPanel.updateSelectedDataSet(extractActionTemplateFromFormSubscribeTemplatePanel());
            }
        });
    }

    public void SetSubscribeTemplatePanel(DataSetsPanel dataSetsPanel, ExecutionPanel executionPanel){
        this.dataSetsPanel = dataSetsPanel;
        this.executionPanel = executionPanel;
    }

    private DataSet extractActionTemplateFromFormSubscribeTemplatePanel(){
        DataSet formActionDataSet = new DataSet();
        formActionDataSet.setName(testIdentifiantTextField.getText());
        formActionDataSet.setVin(vinTextField.getText());
        formActionDataSet.setNumeroContrat(numContratTextField.getText());
        formActionDataSet.setNumeroClient(numCLientTextField.getText());
        formActionDataSet.setEvenementContrat(EvenementTextField.getText());
        formActionDataSet.setKmCompteur(kmCompteurTextField.getText());
        formActionDataSet.setDpiMadax(testDpiMadax.getText());
        formActionDataSet.setDdc(testDdc.getText());
        return formActionDataSet;
    }

    public IhmTestReport extractExecutionTemplateFromFormSubscribeTemplatePanel(){

        IhmTestReport actionIhmTestReport = new IhmTestReport(extractActionTemplateFromFormSubscribeTemplatePanel());
        return actionIhmTestReport;
    }


    public void UpdateForm(DataSet actionDataSet) {
        if (actionDataSet != null){
            testIdentifiantTextField.setText(actionDataSet.getName());
            vinTextField.setText(actionDataSet.getVin());
            numContratTextField.setText(actionDataSet.getNumeroContrat());
            numCLientTextField.setText(actionDataSet.getNumeroClient());
            EvenementTextField.setText(actionDataSet.getEvenementContrat());
            kmCompteurTextField.setText(actionDataSet.getKmCompteur());
            testDpiMadax.setText(actionDataSet.getDpiMadax());
            testDdc.setText(actionDataSet.getDdc());
            if(actionDataSet.isTestPlayed() == false) {
                mainControler.getMainView().getSubscribeTemplatePanel().setGlobalGridPanelColor(new java.awt.Color(200, 150, 120));
            }else {
                mainControler.getMainView().getSubscribeTemplatePanel().setGlobalGridPanelColor(new java.awt.Color(100, 150, 200));

            }
        }
    }


    public Checkbox getIeCheckBox() {
        return ieCheckBox;
    }

    public Checkbox getFirefoxCheckBox() {
        return firefoxCheckBox;
    }

    public void setGlobalGridPanelColor(Color color){
        globalGridPanel.setBackground(color);
    }
}
