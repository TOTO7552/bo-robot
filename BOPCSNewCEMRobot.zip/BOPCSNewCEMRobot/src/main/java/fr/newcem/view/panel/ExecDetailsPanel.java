package fr.newcem.view.panel;

import fr.newcem.model.IhmTestReport;
import fr.newcem.userInterfaceControler.MainControler;
import fr.newcem.view.tableModel.ExecutionTableModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * Created by moi on 02/01/2017.
 */
public class ExecDetailsPanel extends JPanel {

    private JTable executionTable;
    private ExecutionTableModel executionTableModel;
    private MainControler mainControler;

    private JPanel testResult;
    private JLabel testName ;
    private JLabel navigator ;
    private JLabel testStatut ;
    private JLabel testTime ;
    private JLabel testStartingDate ;
    private JLabel testFinishedDate ;
    private JLabel screenShotsDirectory;

    private TextArea detailsText;
    private TextArea commentText;
    private JButton commentButton;

    public ExecDetailsPanel(MainControler mainControler, JTable executionTable, ExecutionTableModel executionTableModel) {
        this.mainControler = mainControler;
        this.executionTable = executionTable;
        this.executionTableModel = executionTableModel;

        this.init();
    }

    public void init() {

        JPanel verticalWrapper = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        this.setBorder(BorderFactory.createLineBorder(Color.black));

        testResult = new JPanel(new GridBagLayout());
        //testResult.setPreferredSize(new Dimension(270, 100));
        testName = new JLabel("N/A");
        navigator = new JLabel("N/A");
        testStatut = new JLabel("N/A");
        testTime = new JLabel("N/A");
        testStartingDate = new JLabel("N/A");
        testFinishedDate = new JLabel("N/A");
        screenShotsDirectory = new JLabel("N/A");
        gbc.gridx = 0;
        gbc.gridy = 0;
        testResult.add(new JLabel("\n Id. test:" ), gbc);
        gbc.gridx = 1;

        testResult.add(testName, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        testResult.add(new JLabel("Navigateur:\n" ), gbc);
        gbc.gridx = 1;
        testResult.add(navigator, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        testResult.add(new Label("Statut test:\n" ), gbc);
        gbc.gridx = 1;
        testResult.add(testStatut, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        testResult.add(new Label("Temps test:\n" ), gbc);
        gbc.gridx = 1;
        testResult.add(testTime, gbc);
        gbc.gridx = 0;
        gbc.gridy = 4;
        testResult.add(new Label("Début test:\n" ), gbc);
        gbc.gridx = 1;
        testResult.add(testStartingDate, gbc);
        gbc.gridx = 0;
        gbc.gridy = 5;
        testResult.add(new Label("Fin test:\n" ), gbc);
        gbc.gridx = 1;
        testResult.add(testFinishedDate, gbc);
        gbc.gridx = 0;
        gbc.gridy = 6;
        testResult.add(new Label("Screenshots:\n" ), gbc);
        gbc.gridx = 1;
        testResult.add(screenShotsDirectory, gbc);

        gbc.gridx = 0;
        gbc.gridy = 0;
        JScrollPane resultScrollPane = new JScrollPane(testResult);
        resultScrollPane.setPreferredSize(new Dimension(290, 70));
        verticalWrapper.add(resultScrollPane, gbc);

        detailsText = new TextArea();
        detailsText.setPreferredSize(new Dimension(285, 65));
        detailsText.setEditable(false);
        //detailsPanel.add(detailsText);

        gbc.gridx = 0;
        gbc.gridy = 1;
        verticalWrapper.add(detailsText, gbc);

        JPanel commentWrapper = new JPanel();
        gbc.gridx = 0;
        gbc.gridy = 0;
        commentButton = createCommentButton();
        commentWrapper.add(commentButton, gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        commentText = new TextArea();
        commentText.setPreferredSize(new Dimension(150, 40));
        commentWrapper.add(commentText, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        verticalWrapper.add(commentWrapper,gbc);

        this.add(verticalWrapper);
    }

    private JButton createCommentButton() {
        return new JButton(new AbstractAction("Commentaire") {
            public void actionPerformed(ActionEvent e) {
                if(executionTable.getSelectedRow() == -1)
                    return;
                IhmTestReport ihmTestReport = executionTableModel.getIhmTestReportTableListModel().get(executionTable.getSelectedRow());
                ihmTestReport.setTestorComment(commentText.getText());
                //executionTableModel.fireTableDataChanged();
            }
        });
    }

    public void updateForms(){
        if(executionTable.getSelectedRow() == -1)
            return;

        IhmTestReport ihmTestReport = executionTableModel.getIhmTestReportTableListModel().get(executionTable.getSelectedRow());
        testName.setText(ihmTestReport.getName());
        navigator.setText(ihmTestReport.getNavigator());
        testStatut.setText(ihmTestReport.getExecutionStatut());
        if(testStatut.getText() == "ok"){
            testStatut.setForeground(new java.awt.Color(100, 150, 100));
            this.setBackground(new java.awt.Color(100, 150, 100));
        }
        if(testStatut.getText() == "anomalie détectée"){
            testStatut.setForeground(new java.awt.Color(220, 100, 50));
            this.setBackground(new java.awt.Color(220, 100, 50));
        }
        if(testStatut.getText() == "interrompue"){
            testStatut.setForeground(new java.awt.Color(230, 120, 100));
            this.setBackground(new java.awt.Color(230, 120, 100));
        }
        testTime.setText(String.valueOf(ihmTestReport.getExecutionTime()) +" ms");
        testStartingDate.setText(ihmTestReport.getStartedExecutionDate());
        testFinishedDate.setText(ihmTestReport.getFinishedExecutionDate());
        screenShotsDirectory.setText(ihmTestReport.getScreenShotDirectory().toString());
        detailsText.setText(ihmTestReport.getExecutionDetailsString());
        commentText.setText(ihmTestReport.getTestorComment());

    }
}
