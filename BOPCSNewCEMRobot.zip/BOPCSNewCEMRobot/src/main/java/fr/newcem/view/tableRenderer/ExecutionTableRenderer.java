package fr.newcem.view.tableRenderer;

import fr.newcem.view.tableModel.ExecutionTableModel;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

/**
 * Created by moi on 28/12/2016.
 */
public class ExecutionTableRenderer extends DefaultTableCellRenderer
{
    private ExecutionTableModel executionTableModel;

    public Component getTableCellRendererComponent(JTable table, Object value, boolean   isSelected, boolean hasFocus, int row, int column)
    {
        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        if(!isSelected) {

            if (executionTableModel.getIhmTestReportTableListModel().get(row).isTestPlayed()) {
                if (executionTableModel.getIhmTestReportTableListModel().get(row).getExecutionStatut().equals("ok"))
                    c.setBackground(new java.awt.Color(100, 150, 100));
                else if (executionTableModel.getIhmTestReportTableListModel().get(row).getExecutionStatut().equals("anomalie détectée"))
                    c.setBackground(new java.awt.Color(220, 100, 50));
                else if (executionTableModel.getIhmTestReportTableListModel().get(row).getExecutionStatut().equals("interrompue"))
                    c.setBackground(new java.awt.Color(230, 120, 100));

            }
            else c.setBackground(new java.awt.Color(255, 255, 255));
        }
        return c;
    }

    public void setModel(ExecutionTableModel dataSetsTableModel){
        this.executionTableModel = dataSetsTableModel;
    }

}