package fr.newcem.view.panel;
import fr.newcem.userInterfaceControler.MainControler;
import fr.newcem.model.DataSet;
import fr.newcem.view.Listener.TemplateListSelectionListener;
import fr.newcem.view.tableRenderer.DataSetsTableRenderer;
import fr.newcem.view.tableModel.DataSetsTableModel;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import java.awt.*;

public class DataSetsPanel extends JPanel  {
    private MainControler mainControler;

    private JTable dataSetsTable;
    private SubscribeTemplatePanel subscribeTemplatePanel;
    private DataSetsTableModel dataSetTableModel;

    public DataSetsPanel(MainControler mainControler, SubscribeTemplatePanel subscribeTemplatePanel) {
        this.mainControler = mainControler;
        this.subscribeTemplatePanel = subscribeTemplatePanel;
        this.init();
    }

    public void init() {

        this.setLayout(new BorderLayout());
        this.setPreferredSize(new Dimension(600, 200));

        this.dataSetTableModel = new DataSetsTableModel(mainControler);
        this.dataSetsTable = new JTable(dataSetTableModel);
        DataSetsTableRenderer dataSetsTableRenderer = new DataSetsTableRenderer();
        dataSetsTable.setDefaultRenderer(Object.class, dataSetsTableRenderer);
        this.dataSetTableModel.setJTable(dataSetsTable);
        this.dataSetTableModel.setJTableRenderer(dataSetsTableRenderer);
        dataSetsTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        JScrollPane scrollPane = new JScrollPane(dataSetsTable);
        scrollPane.createHorizontalScrollBar();

        dataSetsTable.getSelectionModel().addListSelectionListener(new TemplateListSelectionListener(){
            public void valueChanged(ListSelectionEvent event) {

                subscribeTemplatePanel.UpdateForm(dataSetTableModel.getSelectedDataSet());
                //System.out.println(dataSetsTable.getValueAt(dataSetsTable.getSelectedRow(), 0).toString());

            }
        });

        this.add(scrollPane,BorderLayout.CENTER);

    }

    public void addDataSet(DataSet actionDataSet){
        ((DataSetsTableModel) dataSetsTable.getModel()).addDataSet(actionDataSet);
        ((DataSetsTableModel) dataSetsTable.getModel()).fireTableRowsInserted(dataSetsTable.getRowCount() -1 ,dataSetsTable.getRowCount());
    }


    public JTable getDataSetsTable(){
        return this.dataSetsTable;
    }

    public void updateSelectedDataSet(DataSet dataSet){
        ((DataSetsTableModel) dataSetsTable.getModel()).updateCurrentlySelectedTemplateWithFormValue(dataSet);
        ((DataSetsTableModel) dataSetsTable.getModel()).fireTableRowsUpdated(0,dataSetsTable.getRowCount());
    }

    public DataSetsTableModel getDataSetTableModel() {
        return dataSetTableModel;
    }

    public JTable getJTable(){
        return dataSetsTable;
    }

}
