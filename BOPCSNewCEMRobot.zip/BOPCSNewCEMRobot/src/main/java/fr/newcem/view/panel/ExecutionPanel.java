package fr.newcem.view.panel;

import fr.newcem.userInterfaceControler.MainControler;
import fr.newcem.model.IhmTestReport;
import fr.newcem.view.Listener.TemplateListSelectionListener;
import fr.newcem.view.tableRenderer.ExecutionTableRenderer;
import fr.newcem.view.tableModel.ExecutionTableModel;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import java.awt.*;

/**
 * Created by moi on 18/12/2016.
 */
public class ExecutionPanel extends JPanel {

    private JTable executionTable;
    private SubscribeTemplatePanel subscribeTemplatePanel;
    private MainControler mainControler;
    private ExecutionTableModel executionTableModel;
    private ScreenShotsPanel screenShotPanel;
    private ExecDetailsPanel execDetailsPanel;

    public ExecutionPanel(MainControler mainControler, SubscribeTemplatePanel subscribeTemplatePanel) {
        this.mainControler = mainControler;
        this.subscribeTemplatePanel = subscribeTemplatePanel;

        this.init();
    }

    public void init() {

        this.setLayout(new BorderLayout());
        //this.setPreferredSize(new Dimension(1000, 200));

        this.executionTableModel = new ExecutionTableModel();
        this.executionTable = new JTable(executionTableModel);
        this.executionTableModel.setJTable(executionTable);
        ExecutionTableRenderer executionTableRenderer = new ExecutionTableRenderer();
        executionTable.setDefaultRenderer(Object.class, executionTableRenderer);
        this.executionTableModel.setJTableRenderer(executionTableRenderer);
        executionTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        JScrollPane scrollPane = new JScrollPane(executionTable);
        scrollPane.createHorizontalScrollBar();
        this.add(scrollPane, BorderLayout.CENTER);
        scrollPane.setPreferredSize(new Dimension(600, 200));

        executionTable.getSelectionModel().addListSelectionListener(new TemplateListSelectionListener(){
            public void valueChanged(ListSelectionEvent event) {
                screenShotPanel.updateDisplayedScreenShots();
                execDetailsPanel.updateForms();
                execDetailsPanel.repaint();
            }
        });

    }

    public void AddTestExecution(IhmTestReport actionIhmTestReport){
        ((ExecutionTableModel) executionTable.getModel()).AddActionTemplate(actionIhmTestReport);
        //((ExecutionTableModel) executionTable.getModel()).fireTableDataChanged();
    }

    public JTable getExecutionTable(){
        return this.executionTable;
    }

    public ExecutionTableModel getExecutionTableModel(){
        return this.executionTableModel;
    }

    public void setScreenShotPanel(ScreenShotsPanel screenShotPanel){
        this.screenShotPanel = screenShotPanel;
    }

    public void setExecDetailsPanel(ExecDetailsPanel execDetailsPanel){
        this.execDetailsPanel = execDetailsPanel;
    }
}
