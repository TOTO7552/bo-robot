package fr.newcem.view.Listener;

import javax.swing.*;
import java.awt.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class TemplateListSelectionListener implements  ListSelectionListener {


    public void valueChanged(ListSelectionEvent e) {

    }
}
