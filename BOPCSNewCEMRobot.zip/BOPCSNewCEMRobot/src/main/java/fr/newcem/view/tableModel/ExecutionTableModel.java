package fr.newcem.view.tableModel;

import fr.newcem.model.IhmTestReport;
import fr.newcem.view.tableRenderer.ExecutionTableRenderer;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

public class ExecutionTableModel extends AbstractTableModel{
    private static final long serialVersionUID = 1L;

    private List<IhmTestReport> ihmTestReportTableListModel;
    private ExecutionTableRenderer executionTableRenderer;
    private JTable jTable;

    public ExecutionTableModel()  {
        this.ihmTestReportTableListModel = new ArrayList<IhmTestReport>();

    }


    public int getRowCount() {
        return ihmTestReportTableListModel.size();
    }


    public int getColumnCount() {
        return 18;
    }


    public Object getValueAt(int rowIndex, int columnIndex) {
        int i = 0;

        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getName();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getVin();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getNumeroContrat();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getNumeroClient();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getEvenementContrat();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getKmCompteur();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getDpiMadax();
        }

        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getDdc();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getFilMarque();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getFilPdv();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getNavigator();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getStartedExecutionDate();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getFinishedExecutionDate();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getExecutionTime() + " ms";
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getExecutionStatut();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getScreenShotDirectory();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getExecutionDetailsString();
        }
        i++;
        if(columnIndex==i) {
            return ihmTestReportTableListModel.get(rowIndex).getTestorComment();
        }
        return ihmTestReportTableListModel;
    }

    public String getColumnName(int columnIndex){

        int i = 0;
        if(columnIndex==i) {
            return "Id. test";
        }

        i++;
        if(columnIndex==i) {
            return "VIN";
        }

        i++;
        if(columnIndex==i) {
            return "N°Contrat PCS";
        }

        i++;
        if(columnIndex==i) {
            return "N°Client";
        }

        i++;
        if(columnIndex==i) {
            return "Evènement";
        }

        i++;
        if(columnIndex==i) {
            return "Km au compteur";
        }

        i++;
        if(columnIndex==i) {
            return "DPI MADAX";
        }
        i++;
        if(columnIndex==i) {
            return "DDC";
        }
        i++;

        if(columnIndex==i) {
            return "Marque";
        }
        i++;
        if(columnIndex==i) {
            return "PDV";
        }
        i++;
        if(columnIndex==i) {
            return "Navigateur";
        }
        i++;
        if(columnIndex==i) {
            return "Début test";
        }
        i++;
        if(columnIndex==i) {
            return "Fin test";
        }
        i++;
        if(columnIndex==i) {
            return "Temps test";
        }
        i++;
        if(columnIndex==i) {
            return "Statut test";
        }
        i++;
        if(columnIndex==i) {
            return "Screenshots";
        }
        i++;
        if(columnIndex==i) {
            return "Détails exécution";
        }
        i++;
        if(columnIndex==i) {
            return "Commentaire";
        }
        else{return "colonne sans nom";}


    }

    public void setJTable(JTable jTable){
        this.jTable = jTable;
    }


    public List<IhmTestReport> getIhmTestReportTableListModel() {
        return ihmTestReportTableListModel;
    }

    public void AddActionTemplate(IhmTestReport actionIhmTestReport){
        ihmTestReportTableListModel.add(actionIhmTestReport);

    }

    public void setJTableRenderer(ExecutionTableRenderer executionTableRenderer){
        this.executionTableRenderer = executionTableRenderer;
        executionTableRenderer.setModel(this);
    }


}
