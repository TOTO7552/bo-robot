package fr.newcem.view.tableRenderer;

import fr.newcem.view.tableModel.DataSetsTableModel;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

/**
 * Created by moi on 27/12/2016.
 */
public class DataSetsTableRenderer extends DefaultTableCellRenderer
{
    private DataSetsTableModel dataSetsTableModel;

    public Component getTableCellRendererComponent(JTable table, Object value, boolean   isSelected, boolean hasFocus, int row, int column)
    {
        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        if(!isSelected) {
            if (!dataSetsTableModel.getDataSetTableListModel().get(row).isTestPlayed())
                c.setBackground(new java.awt.Color(200, 150, 120));
            else c.setBackground(new java.awt.Color(255, 255, 255));
        }
        return c;
    }

    public void setModel(DataSetsTableModel dataSetsTableModel){
        this.dataSetsTableModel = dataSetsTableModel;
    }

}
