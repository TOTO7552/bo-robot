package fr.newcem.view.tableModel;

import fr.newcem.userInterfaceControler.MainControler;
import fr.newcem.model.DataSet;
import fr.newcem.view.tableRenderer.DataSetsTableRenderer;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by moi on 18/12/2016.
 */
public class DataSetsTableModel extends AbstractTableModel {
    private static final long serialVersionUID = 1L;

    private ArrayList<DataSet> dataSetTableListModel;

    private JTable jTable;

    private DataSetsTableRenderer dataSetsTableRenderer;
    private MainControler mainControler;

    private ArrayList<String> xlsHeaderLabel;

    public DataSetsTableModel(MainControler mainControler)  {
        this.mainControler = mainControler;
        xlsHeaderLabel = new ArrayList<String>();
        this.dataSetTableListModel = new ArrayList<DataSet>();
    }

    public JTable getJTable() {
        return jTable;
    }

    public void setJTable(JTable jTable){
        this.jTable = jTable;
    }

    public int getRowCount() {
        return dataSetTableListModel.size();
    }

    public int getColumnCount() {
        return xlsHeaderLabel.size();
    }

    public String getColumnName(int column){
        return xlsHeaderLabel.get(column);
    }

    public void setXlsHeaderLabel(ArrayList<String> xlsHeaderLabel) {
        this.xlsHeaderLabel = new ArrayList<String>();
        this.xlsHeaderLabel = xlsHeaderLabel;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {

        //if(mainControler.getImportedDataSets().length>0)
        //return mainControler.getImportedDataSets()[rowIndex].getTestDataList()[columnIndex].toString();
        //else return "not initialized";

        return getValueAt2(rowIndex,columnIndex);
    }

    public Object getValueAt2(int rowIndex, int columnIndex) {

        if(columnIndex==0) {
            return dataSetTableListModel.get(rowIndex).getName();
        }
        if(columnIndex==1) {
            return dataSetTableListModel.get(rowIndex).getVin();
        }
        if(columnIndex==2) {
            return dataSetTableListModel.get(rowIndex).getEvenementContrat();
        }

        if(columnIndex==3) {
            return dataSetTableListModel.get(rowIndex).getNumeroClient();
        }

        if(columnIndex==4) {
            return dataSetTableListModel.get(rowIndex).getEvenementContrat();
        }
        if(columnIndex==5) {
            return dataSetTableListModel.get(rowIndex).getKmCompteur();
        }
        if(columnIndex==6) {
            return dataSetTableListModel.get(rowIndex).isTestPlayed();
        }
        return dataSetTableListModel;
    }

    public void addDataSet(DataSet actionDataSet){
        dataSetTableListModel.add(actionDataSet);
    }
    public boolean isCellEditable(int row, int col)
    { return true; }

    public DataSet getSelectedDataSet(){
        if(jTable.getModel().getRowCount()>0){
        if(jTable.getSelectedRow() > -1)
        return  dataSetTableListModel.get(jTable.getSelectedRow());
        else return  dataSetTableListModel.get(0);
        }else return null;
    }

    public void updateCurrentlySelectedTemplateWithFormValue(DataSet dataSet){
        dataSetTableListModel.set(jTable.getSelectedRow(), dataSet);
    }


    public List<DataSet> getDataSetTableListModel(){
        return this.dataSetTableListModel;
    }

    public void ClearTableModel(){
        dataSetTableListModel = new ArrayList<DataSet>();
    }

    public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }

    public void setJTableRenderer(DataSetsTableRenderer dataSetsTableRenderer){
        this.dataSetsTableRenderer = dataSetsTableRenderer;
        dataSetsTableRenderer.setModel(this);
    }

    public DataSetsTableRenderer getDataSetsTableRenderer() {
        return dataSetsTableRenderer;
    }
}
